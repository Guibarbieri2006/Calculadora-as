package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;


public class CalculadoraActivity extends AppCompatActivity {

    Button btnSoma, btnSubtracao, btnIMC;
    TextView txtResultado;
    EditText edtValor1, edtValor2;
    Integer num1, num2, Soma, Subtracao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);
        // BOTAO DE SOMA
        btnSoma = findViewById(R.id.btnSoma);
        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText edtValor1 = findViewById(R.id.edtValor1);
                EditText edtValor2 = findViewById(R.id.edtValor2);

                Integer num1 = Integer.parseInt(edtValor1.getText().toString());
                Integer num2 = Integer.parseInt(edtValor2.getText().toString());
                Integer soma = num1 + num2;

                TextView txtResultado = findViewById(R.id.txtResultado);
                txtResultado.setText(Integer.toString(soma));
            }
        });

        // BOTAO DE SUBTRACAO
        btnSubtracao = findViewById(R.id.btnSubtracao);
        btnSubtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText edtValor1 = findViewById(R.id.edtValor1);
                EditText edtValor2 = findViewById(R.id.edtValor2);

                Integer num1 = Integer.parseInt(edtValor1.getText().toString());
                Integer num2 = Integer.parseInt(edtValor2.getText().toString());
                Integer subtracao = num1 - num2;

                TextView txtResultado = findViewById(R.id.txtResultado);
                txtResultado.setText(Integer.toString(subtracao));
            }
        });
        btnIMC = findViewById(R.id.btnIMC);

    }
}