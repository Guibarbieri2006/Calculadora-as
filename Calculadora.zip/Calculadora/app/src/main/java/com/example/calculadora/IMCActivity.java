package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;


public class IMCActivity extends AppCompatActivity {

    Button btnCalcular;
    EditText edtPeso,edtAltura;
    Double peso, altura, imc;
    TextView txtIMC, txtSituacao;
    String resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        btnCalcular = findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

        EditText edtPeso = findViewById(R.id.edtPeso);
        Double peso = Double.parseDouble(edtPeso.getText().toString());

        EditText edtAltura = findViewById(R.id.edtAltura);
        Double altura = Double.parseDouble(edtAltura.getText().toString());

        imc = peso/ (altura*altura);

        TextView txtIMC = findViewById(R.id.txtIMC);
        txtIMC.setText(Double.toString(imc));

        if(imc < 17) {
            String resultado = "Muito abaixo do peso";
        } else if (imc >= 17 && imc < 18.5) {
            String resultado = "Abaixo do peso";
        } else if (imc >= 18.5 && imc < 25) {
            String resultado = "Peso normal";
        } else if (imc >= 25 && imc < 30) {
            String resultado = "Acima do peso";
        }     else if (imc >= 30 && imc < 35) {
            String resultado = "Obesidade I";
        }  else if (imc >= 35 && imc < 40) {
            String resultado = "Obesidade II (severa)";
        } else {
            String resultado = "Obesidade III (mórbida)";
        }

        TextView txtSituacao = findViewById(R.id.txtSituacao);
        txtSituacao.setText(resultado);

}
